
namespace lab{
    public class PSpec {
        public string spec;
        //p = "foo :: bar baz bam | boom"
        public PSpec(string p){
            this.spec=p;
        }
    }
} //namespace
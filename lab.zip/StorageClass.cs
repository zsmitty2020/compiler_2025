namespace lab{

    public enum StorageClass{
        NO_STORAGE_CLASS=-1,
        PRIMITIVE=0
    }

}
namespace lab{
    
    public abstract class Opcode {
       public abstract void output(StreamWriter w);
    }

}